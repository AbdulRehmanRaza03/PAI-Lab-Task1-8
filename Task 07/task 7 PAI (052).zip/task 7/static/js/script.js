console.log("News Website Loaded");

alert("Welcome to Latest News Website");