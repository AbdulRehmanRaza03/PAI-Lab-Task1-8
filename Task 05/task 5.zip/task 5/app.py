from flask import Flask, render_template, request
import cv2
import numpy as np
import os

app = Flask(__name__)

UPLOAD_FOLDER = "static/images"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def home():
    return render_template("index.html")

@app.route('/process', methods=['POST'])
def process_image():
    if 'image' not in request.files:
        return "No file uploaded"

    file = request.files['image']
    if file.filename == '':
        return "No selected file"

    uploaded_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(uploaded_path)

    img = cv2.imread(uploaded_path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    gray = gray.astype(np.uint8)  


    filename, ext = os.path.splitext(file.filename)
    if ext.lower() not in ['.jpg', '.jpeg', '.png', '.bmp']:
        ext = '.png'

    processed_filename = f"processed_{filename}{ext}"
    processed_path = os.path.join(UPLOAD_FOLDER, processed_filename)
    cv2.imwrite(processed_path, gray)


    uploaded_image = f"static/images/{file.filename}"
    processed_image = f"static/images/{processed_filename}"

    return render_template("index.html", uploaded_image=uploaded_image, processed_image=processed_image)

if __name__ == "__main__":
    app.run(debug=True)