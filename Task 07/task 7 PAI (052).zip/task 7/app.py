import requests
from flask import Flask, render_template

app = Flask(__name__)


api_key = "3ec33b688438431a97498651cfddf519"


url = f"https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey={api_key}"

@app.route('/')
def news():

    response = requests.get(url)

    if response.status_code == 200:
        news_data = response.json()
        articles = news_data["articles"]
    else:
        articles = []

    return render_template('index.html', articles=articles)


if __name__ == "__main__":
    app.run(debug=True)